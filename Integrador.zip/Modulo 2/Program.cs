﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integrador_OO {
    internal class Program {
        static void Main(string[] args) {

            //Ingreso de datos

            //Mostrar datos de vuelta

            //Preguntar si son correctos

            //Mostrar carreras

            //Exit

            //Defino variables

            string nombre;
            string apellido;
            int edad;
            string correo;

            string[] carreras = { "Carrera 1", "Carrera 2", "Carrera 3", "Carrera 6" };

            

            Console.WriteLine("Ingrese nombre: ");
            nombre = Console.ReadLine();
            Console.WriteLine("Ingrese apellido: ");
            apellido = Console.ReadLine();
            Console.WriteLine("Ingrese edad: ");
            edad = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese correo: ");
            correo = Console.ReadLine();

            Console.WriteLine($"Son los datos correctos: \n " +
                $" Nombre: {nombre} \n" +
                $" Apellido: {apellido} \n" +
                $" Edad: {edad} \n" +
                $" Correo: {correo} \n");
                string verificar = Console.ReadLine();

            if(verificar != "s") {
                Console.WriteLine("Datos incorrecto. Ejecutar nuevamente la aplicacion");
                goto salida;
            }

            Console.WriteLine("Lista carreras:");
            mostrarCarreras(carreras);

            int eleccion = Convert.ToInt32(Console.ReadLine());
            string carreraElegida = elegirCarrera(eleccion, carreras);

            if(carreraElegida == null) {
                Console.WriteLine("Carrera inexistente. " +
                    "Datos incorrectos");
                goto salida;
            }

            Console.WriteLine("Constancia Inscripcion");
            Console.WriteLine($"\n " +
               $" Nombre: {nombre} \n" +
               $" Apellido: {apellido} \n" +
               $" Edad: {edad} \n" +
               $" Correo: {correo} \n " +
               $" Carrera: {carreraElegida}");



        salida:
            Console.ReadKey();

        }

        public static void mostrarCarreras(string[] carreras) {
            //iteramos y mostramos
            int i = 1;
            foreach(string carrera in carreras){
                Console.WriteLine($"{i}. {carrera}");
                i++;
            }
        }
        public static string elegirCarrera(int eleccion, string[] carreras) {
            if (eleccion < 0 || eleccion > carreras.Length) {
                return null;
            }
            return carreras[eleccion-1];
        }
    }
}
