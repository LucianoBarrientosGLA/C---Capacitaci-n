﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modulo_5 {
    internal class Program {
        static void Main(string[] args) {

            //Ingreso de datos

            //Mostrar datos de vuelta

            //Preguntar si son correctos

            //Mostrar carreras

            //Exit

            //Defino variables

            string nombre;
            string apellido;
            int edad;
            string correo;

            string[] carreras = { "Carrera 1", "Carrera 2", "Carrera 3", "Carrera 6" };
            string[] cursos;


            Console.WriteLine("Ingrese nombre: ");
            nombre = Console.ReadLine();
            Console.WriteLine("Ingrese apellido: ");
            apellido = Console.ReadLine();
            Console.WriteLine("Ingrese edad: ");
            edad = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese correo: ");
            correo = Console.ReadLine();

            Console.WriteLine($"\nSon los datos correctos: \n" +
                $" Nombre: {nombre} \n" +
                $" Apellido: {apellido} \n" +
                $" Edad: {edad} \n" +
                $" Correo: {correo} \n");
            Console.WriteLine($"Ingresar s si los datos estan bien, otra letra en caso negativo \n ");
            string verificar = Console.ReadLine();



            if (verificar != "s") {
                Console.WriteLine("Datos incorrectos. Ejecutar nuevamente la aplicacion");
                goto salida;
            }

            Console.WriteLine("\nLista carreras: \n");
            mostrarLista(carreras);

            int eleccion = Convert.ToInt32(Console.ReadLine());
            string carreraElegida = elegirCarrera(eleccion, carreras);

            if (carreraElegida == null) {
                Console.WriteLine("Carrera inexistente. " +
                    "Datos incorrectos");
                goto salida;
            }

            Console.WriteLine("\nConstancia Inscripcion a carrera");
            Console.WriteLine($"\n" +
               $" Nombre: {nombre} \n" +
               $" Apellido: {apellido} \n" +
               $" Edad: {edad} \n" +
               $" Correo: {correo} \n" +
               $" Carrera: {carreraElegida}");

            //inscripcion a cursos
            string[] cursosdisponibles = inscripcionACursos(carreraElegida);
          /*  Console.WriteLine("cursos disponibles: ");
            mostrarLista(cursosdisponibles);*/


            string[] cursosInscripto = new string[0];
            int eleccionCurso = 1;
            int valorEleccion;
            while (cursosInscripto.Length <= 5 && eleccionCurso > 0) {
                Console.WriteLine("\nCursos disponibles");
                mostrarLista(cursosdisponibles);
                eleccionCurso = Convert.ToInt32(Console.ReadLine());
                valorEleccion = eleccionCurso;
                valorEleccion--;
                cursosInscripto = inscribirACurso(cursosdisponibles, valorEleccion, cursosInscripto);
                foreach(string s in cursosInscripto ) Console.WriteLine(s);
  
            }

            Console.WriteLine("\nConstancia Inscripciones");
            Console.WriteLine($"\n" +
               $" Nombre: {nombre} \n" +
               $" Apellido: {apellido} \n" +
               $" Edad: {edad} \n" +
               $" Correo: {correo} \n" +
               $" Carrera: {carreraElegida}");
            Console.WriteLine("\nCursos inscripto");
            mostrarLista(cursosInscripto);


        salida:
            Console.ReadKey();

        }

        private static string[] inscribirACurso(string[] cursosdisponibles, int eleccionCurso, string[] cursosInscripto) {
            if (eleccionCurso >= 0 && eleccionCurso <= cursosdisponibles.Length) {
                string curso = cursosdisponibles[eleccionCurso];
                for (int i = 0; i < cursosInscripto.Length; i++) {
                    if (curso == cursosInscripto[i])
                        return cursosInscripto;
                }
                string[] cursos = new string[cursosInscripto.Length + 1];
                for(int i = 0; i < cursosInscripto.Length; i++) {
                    cursos[i] = cursosInscripto[i];
                }
                cursos[cursos.Length - 1] = curso;
                cursosInscripto = cursos;
            }
            return cursosInscripto;
        }

        public static void mostrarLista(string[] lista) {
            //iteramos y mostramos
            int i = 1;
            foreach (string elemento in lista) {
                Console.WriteLine($"{i}. {elemento}");
                i++;
            }
        }
        public static string elegirCarrera(int eleccion, string[] carreras) {
            if (eleccion < 0 || eleccion > carreras.Length) {
                return null;
            }
            return carreras[eleccion - 1];
        }

        public static string[] inscripcionACursos(string carreraElegida) {
            switch (carreraElegida) {
                case "Carrera 1":
                    return new string[] { "Quimica 1", "Topologia 2", "Matematica 3", "Analisis 2", "Matematica 1", "Analisis 2.5" };
                case "Carrera 2":
                    return new string[] { "Arte 10", "Danza 20", "Floreria", "Origami" };
                case "Carrera 3":
                    return new string[] { "Kinesio 30", " Dados", "Traumato", "Otorrino", "Pediatria" };
                case "Carrera 6":
                    return new string[] { "Materia 55", "Materia 66", "Materia 77", "Materia 88", "Materia 99", "Materia 22" };
                default:
                    return new string[] { "" };
            }
        }
    }
}